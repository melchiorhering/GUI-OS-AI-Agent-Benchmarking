## Task Overview

========

In this task, we want to integrate an existing dbt project `dags/dbt/jaffle_shop` into an Airflow DBT task group using Astro and Cosmos. Please finish the code in `dags/jaffle_shop_dag.py` and name the target DAG `jaffle_shop_dag`.

========

## Environment Dependencies

- Docker image: The required Docker virtual environment has been configured in `Dockerfile`.
- Provider package: The Postgres provider package for the target data warehouse is also added in `requirements.txt`.
- Astro Web Server: The Astro web server has been launched in localhost with port 8080.

========

## Connection to Postgres Database

The connection to Postgresql database has been configured with:
- connection_id: postgres_conn
- connection_type: Postgres
- db_name: jaffle_shop
- db_schema: public
- host: 172.17.0.1
- port: 5432
- username: user
- password: password
