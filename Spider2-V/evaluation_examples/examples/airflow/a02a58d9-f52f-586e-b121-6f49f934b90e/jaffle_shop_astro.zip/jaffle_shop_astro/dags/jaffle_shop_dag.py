"""
### Run a dbt Core project as a task group with Cosmos
"""
import os

CONNECTION_ID = "postgres_conn"
DB_NAME = "jaffle_shop"
SCHEMA_NAME = "public"
TARGET_NAME = "dev"

# The path to the dbt project
DBT_PROJECT_PATH = f"{os.environ['AIRFLOW_HOME']}/dags/dbt/jaffle_shop"
# The path where Cosmos will find the dbt executable
# in the virtual environment created in the Dockerfile
DBT_EXECUTABLE_PATH = f"{os.environ['AIRFLOW_HOME']}/dbt_venv/bin/dbt"
